"""Database package for Rosy."""
