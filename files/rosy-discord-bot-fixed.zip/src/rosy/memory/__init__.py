"""Memory subsystem for Rosy."""
