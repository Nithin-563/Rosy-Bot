"""Business services for Rosy."""
